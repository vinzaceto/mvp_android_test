package com.vinzaceto.mvptest.weather

class WeatherObject {
    lateinit var field1: String
    lateinit var field2: String
}