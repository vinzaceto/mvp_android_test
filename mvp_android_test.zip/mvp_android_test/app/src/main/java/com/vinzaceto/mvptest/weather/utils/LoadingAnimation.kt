package com.vinzaceto.mvptest.weather.utils

/**
 * NTT Data Italia S.p.A.
 * File created on 22/02/2019.
 *
 * @author Vincenzo Aceto - vincenzo.aceto@nttdata.com
 * @version 1.0
 */