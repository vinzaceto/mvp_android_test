# mvp_android_test
This project shows how MVP works and how to use mvp with Kotlin
